/ readme.txt */
/* Christopher Brant */
/* SDE2 Contents and Comments */
/* Due 4/10/18 */

Located in this archive cbrant-sde2.zip are the following files:
readme.txt (This file)
exampleData.caml (Example testing data used for preliminary tests)
testData.caml (My personal testing data used in sde2.log tests)
sde2.caml (Includes definitions of all functions)
sde2.log (Includes 3 or more distinct tests for each function)

The Pledge:
On my honor I have neither given nor received aid on this exam.
SIGN: Christopher D. Brant.
