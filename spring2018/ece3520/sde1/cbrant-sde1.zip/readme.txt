/* readme.txt */
/* Christopher Brant */
/* SDE1 Contents and Comments */
/* Due 3/6/18 */

Located in this archive cbrant-sde1.zip are the following files:
sde1.pro (Includes definitions of all predicates)
sde1.log (Includes 3 distinct tests for each predicate)
readme.txt (This file)
exampleData.pro (Includes the example data given to us, used for initial testing)
testData.pro (Includes the testing data created that is used in sde1.log)

The Pledge:
On my honor I have neither given nor received aid on this exam.
SIGN: Christopher D. Brant.